package com.youth.banner.listener;

public interface OnBannerListener {
    public void OnBannerClick(int position);
}
